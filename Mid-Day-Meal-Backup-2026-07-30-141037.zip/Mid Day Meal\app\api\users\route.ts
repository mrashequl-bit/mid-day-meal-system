import { NextResponse } from "next/server";
import { ensureDatabase } from "../../../db/bootstrap";
import { requireSuperAdmin } from "../../lib/auth";
import { hashPassword } from "../../lib/password";

export async function GET() {
  if (!(await requireSuperAdmin())) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  try {
    const db = await ensureDatabase();
    const result = await db.prepare(
      `SELECT u.id, u.username, u.name, u.role, u.area_code, u.is_active,
       u.email, u.phone, u.bio, u.address, u.photo_base64, u.designation,
       a.name_bn AS area_name
       FROM users u LEFT JOIN areas a ON a.code = u.area_code
       ORDER BY CASE WHEN u.role = 'super_admin' THEN 0 ELSE 1 END, u.name`
    ).all();
    return NextResponse.json(result.results);
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Users unavailable" },
      { status: 500 },
    );
  }
}

export async function POST(request: Request) {
  if (!(await requireSuperAdmin())) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  try {
    const data = await request.json() as Record<string, unknown>;
    const db = await ensureDatabase();
    await db.prepare(
      `INSERT INTO users
       (username, password, name, role, area_code, is_active, email, phone,
        bio, address, designation)
       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`
    ).bind(
      String(data.username ?? "").trim(),
      await hashPassword(String(data.password ?? "")),
      String(data.name ?? "").trim(),
      String(data.role ?? "viewer"),
      data.role === "area_manager" ? String(data.area_code ?? "") : null,
      data.is_active === 0 ? 0 : 1,
      String(data.email ?? "").trim(),
      String(data.phone ?? "").trim(),
      String(data.bio ?? "").trim(),
      String(data.address ?? "").trim(),
      String(data.designation ?? "").trim(),
    ).run();
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "User save failed" },
      { status: 500 },
    );
  }
}
