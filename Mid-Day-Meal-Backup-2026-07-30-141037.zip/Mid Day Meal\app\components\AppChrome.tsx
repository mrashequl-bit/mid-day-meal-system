"use client";

import { ReactNode, useMemo, useState } from "react";
import {
  Boxes,
  CalendarDays,
  Handshake,
  LayoutDashboard,
  MapPinned,
  ReceiptText,
} from "lucide-react";
import "./DashboardApp.css";
import "./sidebar-collapse.css";
import "./header-cleanup.css";
import "./index.css";

type AppChromeProps = {
  activeNav?: "dashboard" | "areas" | "account" | "distribution" | "stock" | "suppliers";
  children: ReactNode;
};

const dateFormatter = new Intl.DateTimeFormat("bn-BD", {
  dateStyle: "full",
});

const navItems = [
  { id: "dashboard", label: "ড্যাশবোর্ড", icon: LayoutDashboard, href: "/" },
  { id: "areas", label: "অঞ্চল", icon: MapPinned, href: "/" },
  { id: "account", label: "হিসাব", icon: ReceiptText, href: "/" },
  { id: "distribution", label: "বিতরণ পরিকল্পনা", icon: CalendarDays, href: "/" },
  { id: "stock", label: "স্টক", icon: Boxes, href: "/" },
  { id: "suppliers", label: "সরবরাহকারী", icon: Handshake, href: "/" },
] as const;

export function AppChrome({ activeNav = "dashboard", children }: AppChromeProps) {
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const today = useMemo(() => dateFormatter.format(new Date()), []);

  function navigate(href: string) {
    window.location.href = href;
  }

  return (
    <div className={sidebarCollapsed ? "app-shell sidebar-is-collapsed" : "app-shell"}>
      <aside className={sidebarCollapsed ? "sidebar sidebar-collapsed no-print" : "sidebar no-print"}>
        <div className="brand">
          <span className="brand-seal">মি</span>
          <div>
            <strong>মিড-ডে মিল</strong>
            <small>সরবরাহ ব্যবস্থাপনা</small>
          </div>
        </div>
        <button
          className="desktop-sidebar-toggle"
          type="button"
          aria-label={sidebarCollapsed ? "সাইডবার ওপেন করুন" : "সাইডবার ক্লোজ করুন"}
          aria-expanded={!sidebarCollapsed}
          onClick={() => setSidebarCollapsed((current) => !current)}
        >
          {sidebarCollapsed ? "›" : "‹"}
        </button>
        <nav aria-label="প্রধান মেনু">
          {navItems.map((item) => {
            const Icon = item.icon;
            return (
              <button
                aria-current={activeNav === item.id ? "page" : undefined}
                aria-label={item.label}
                className={activeNav === item.id ? "nav-active" : ""}
                key={item.id}
                onClick={() => navigate(item.href)}
                title={item.label}
                type="button"
              >
                <span className="nav-icon" aria-hidden="true">
                  <Icon />
                </span>
                <span className="nav-label">{item.label}</span>
              </button>
            );
          })}
        </nav>
        <div className="sidebar-foot">
          <span className="live-dot" />
          <p>
            <strong>সিস্টেম সচল</strong>
            <small>সর্বশেষ ডেটা: ১২৬ বিদ্যালয়</small>
          </p>
        </div>
      </aside>

      <main className="app-main expense-shell-main">
        <header className="topbar no-print">
          <div>
            <button
              className="mobile-menu"
              type="button"
              onClick={() => navigate("/")}
              aria-label="ড্যাশবোর্ডে যান"
            >
              মি
            </button>
            <p>দুর্গাপুর উপজেলা, নেত্রকোণা</p>
            <small>{today}</small>
          </div>
          <div className="top-actions">
            <button className="alert-button" type="button" aria-label="নোটিফিকেশন">
              ০
            </button>
          </div>
        </header>
        {children}
      </main>
    </div>
  );
}
