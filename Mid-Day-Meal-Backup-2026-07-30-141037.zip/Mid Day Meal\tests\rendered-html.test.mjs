import { access, readFile } from "node:fs/promises";
import { test } from "node:test";
import assert from "node:assert/strict";

const read = (path) => readFile(new URL(`../${path}`, import.meta.url), "utf8");

test("mobile notification icon uses the lucide bell without idle background", async () => {
  const component = await read("app/components/NotificationCenter.tsx");
  const styles = await read("app/components/notification-center.css");
  const accountStyles = await read("app/components/account-profile.css");

  assert.match(component, /import \{ Bell \} from "lucide-react"/);
  assert.match(component, /className="mobile-notification-launcher"/);
  assert.doesNotMatch(component, /🔔/);
  assert.match(
    styles,
    /\.mobile-notification-launcher > span \{[\s\S]*?background: transparent;/,
  );
  assert.match(
    accountStyles,
    /@media \(max-width: 800px\) \{[\s\S]*?\.topbar \.alert-button \{[\s\S]*?display: none !important;/,
  );
  assert.match(
    accountStyles,
    /\.topbar \.alert-button::before,\s*\.topbar \.alert-button::after \{[\s\S]*?content: none !important;[\s\S]*?display: none !important;/,
  );
  assert.doesNotMatch(styles, /background: rgba\(255, 255, 255, \.08\)/);
  assert.doesNotMatch(accountStyles, /background: rgba\(255, 255, 255, \.08\)/);
});

test("expense notifications open the related payment management page", async () => {
  const notificationCenter = await read("app/components/NotificationCenter.tsx");
  const notificationStyles = await read("app/components/notification-center.css");
  const adminExpensePage = await read("app/components/AdminExpenseManagementPage.tsx");

  assert.match(notificationCenter, /area_code\?: string \| null;/);
  assert.match(notificationCenter, /notification\.type === "expense" && notification\.area_code/);
  assert.match(notificationCenter, /\/area-expenses\?area=\$\{encodeURIComponent\(notification\.area_code\)\}#payment-manage/);
  assert.match(notificationCenter, /window\.location\.href = targetUrl/);
  assert.match(notificationCenter, /onClick=\{\(\) => openNotification\(notification\)\}/);
  assert.match(notificationCenter, /পেমেন্ট ম্যানেজ/);
  assert.match(notificationStyles, /\.notification-list article\[role="button"\] \{[\s\S]*?cursor: pointer;/);
  assert.match(adminExpensePage, /new URLSearchParams\(window\.location\.search\)\.get\("area"\)/);
  assert.match(adminExpensePage, /setSelectedArea\(targetArea\)/);
  assert.match(adminExpensePage, /id="payment-manage"/);
});

test("profile launcher is rendered inside the sidebar instead of the header", async () => {
  const dashboard = await read("app/components/DashboardApp.tsx");
  const profileCard = await read("app/components/AccountProfileCard.tsx");
  const accountStyles = await read("app/components/account-profile.css");
  const headerStyles = await read("app/components/header-cleanup.css");

  assert.match(dashboard, /import "\.\/header-cleanup\.css"/);
  assert.doesNotMatch(dashboard, /className: `user-card`/);
  assert.match(profileCard, /import \{ createPortal \} from "react-dom"/);
  assert.match(profileCard, /document\.querySelector\("\.sidebar"\)/);
  assert.match(profileCard, /launcherTarget && createPortal\(launcher, launcherTarget\)/);
  assert.match(accountStyles, /\.sidebar > \.account-profile-launcher \{[\s\S]*?position: static;/);
  assert.match(accountStyles, /\.sidebar-collapsed > \.account-profile-launcher > span:last-child \{[\s\S]*?display: none;/);
  assert.match(headerStyles, /\.topbar \{[\s\S]*?margin-left: -32px;[\s\S]*?padding-right: 32px;/);
  assert.match(headerStyles, /\.top-actions \{[\s\S]*?margin-right: -14px;/);
  assert.match(headerStyles, /@media \(max-width: 800px\) \{[\s\S]*?\.top-actions \{[\s\S]*?margin-right: 0;/);
  assert.match(headerStyles, /@media \(max-width: 800px\) \{[\s\S]*?\.topbar > div:first-child \{[\s\S]*?display: grid;[\s\S]*?grid-template-columns: 40px minmax\(0, 1fr\);/);
  assert.match(headerStyles, /\.topbar \.mobile-menu \{[\s\S]*?grid-row: 1 \/ span 2;/);
  assert.match(headerStyles, /\.topbar > div:first-child > p,[\s\S]*?\.topbar > div:first-child > small \{[\s\S]*?white-space: nowrap;/);
  assert.match(headerStyles, /\.top-actions \.user-card \{[\s\S]*?display: none !important;/);
  assert.doesNotMatch(dashboard, /একদিনের এক আইটেমের অনুমোদিত চাহিদাকে ভিত্তি ধরে পরিকল্পনা ও হিসাব/);
  assert.match(headerStyles, /\.page-head \{[\s\S]*?align-items: center;[\s\S]*?padding-bottom: 18px;/);
  assert.match(headerStyles, /\.page-head > div:first-child > p:last-child \{[\s\S]*?display: none !important;/);
});

test("dashboard cleanup widgets replace operational alert residue", async () => {
  const page = await read("app/page.tsx");
  const reportWidget = await read("app/components/ReportDashboardWidgets.tsx");
  const adminExpensePage = await read("app/components/AdminExpenseManagementPage.tsx");
  const dedicatedExpenseRoute = await read("app/area-expenses/page.tsx");
  const reportStyles = await read("app/components/report-dashboard-widgets.css");

  assert.match(page, /<ReportDashboardWidgets \/>/);
  assert.doesNotMatch(reportWidget, /AdminExpenseManagementPage/);
  assert.match(reportWidget, /window\.location\.assign\("\/area-expenses"\)/);
  assert.match(dedicatedExpenseRoute, /AdminExpenseManagementPage open standalone/);
  assert.match(dedicatedExpenseRoute, /import \{ AppChrome \}/);
  assert.match(dedicatedExpenseRoute, /<AppChrome>/);
  assert.match(dedicatedExpenseRoute, /user\.role !== "super_admin"/);
  assert.match(adminExpensePage, /অঞ্চলভিত্তিক খরচ/);
  assert.match(adminExpensePage, /standalone = false/);
  assert.match(adminExpensePage, /admin-expense-standalone/);
  assert.match(adminExpensePage, /value="all">সকল অঞ্চল/);
  assert.match(adminExpensePage, /selectedArea === "all"/);
  assert.match(adminExpensePage, /পেমেন্ট দিতে নির্দিষ্ট একটি অঞ্চল নির্বাচন করুন/);
  assert.match(adminExpensePage, /পেমেন্ট ম্যানেজ/);
  assert.match(adminExpensePage, /\/api\/my-account/);
  assert.match(adminExpensePage, /\/api\/expenses\?\$\{params\.toString\(\)\}/);
  assert.match(reportWidget, /heading\.textContent = "রিপোর্ট"/);
  assert.match(reportStyles, /\.report-widget-host > article \{[\s\S]*?display: none !important;/);
  assert.match(reportStyles, /\.sidebar nav button\[title="রিপোর্ট"\]/);
  assert.match(reportStyles, /\.print-report > table:first-of-type[\s\S]*?\{\s*display: none !important;/);
  assert.doesNotMatch(reportWidget, /চাহিদা সারসংক্ষেপ|একদিনের এক আইটেমের চাহিদা/);
  assert.doesNotMatch(await read("app/components/DashboardApp.tsx"), /Opening stock যোগ করা হয়নি|বিলের unit price অপেক্ষমাণ/);
});

test("area expense report page has the polished dedicated report layout", async () => {
  const adminExpensePage = await read("app/components/AdminExpenseManagementPage.tsx");
  const appChrome = await read("app/components/AppChrome.tsx");
  const dedicatedExpenseRoute = await read("app/area-expenses/page.tsx");
  const expenseStyles = await read("app/components/admin-expense-management-page.css");

  assert.match(dedicatedExpenseRoute, /<AppChrome>[\s\S]*?<AdminExpenseManagementPage open standalone \/>[\s\S]*?<\/AppChrome>/);
  assert.match(appChrome, /className="app-main expense-shell-main"/);
  assert.match(appChrome, /sidebarCollapsed \? "sidebar sidebar-collapsed no-print" : "sidebar no-print"/);
  assert.match(appChrome, /className="topbar no-print"/);
  assert.doesNotMatch(appChrome, /id: "reports"|label: "রিপোর্ট"|href: "\/area-expenses"/);
  assert.match(adminExpensePage, /admin-expense-standalone/);
  assert.match(expenseStyles, /\.expense-shell-main \.admin-expense-standalone \{[\s\S]*?background: transparent;[\s\S]*?padding: 26px 0 48px;/);
  assert.match(expenseStyles, /\.admin-expense-header \{[\s\S]*?border-radius: 24px;[\s\S]*?box-shadow: 0 18px 45px/);
  assert.match(expenseStyles, /\.admin-expense-header::before \{[\s\S]*?background: linear-gradient\(180deg, var\(--green\), #49b18f\);/);
  assert.match(expenseStyles, /\.admin-expense-filters \{[\s\S]*?border-radius: 18px;[\s\S]*?box-shadow: 0 12px 32px/);
  assert.match(expenseStyles, /\.admin-expense-metrics article \{[\s\S]*?min-height: 118px;[\s\S]*?overflow: hidden;/);
  assert.match(expenseStyles, /\.admin-expense-report,[\s\S]*?\.admin-payment-panel,[\s\S]*?\.admin-expense-details \{[\s\S]*?border-radius: 20px;[\s\S]*?box-shadow: 0 16px 38px/);
  assert.match(expenseStyles, /@media \(max-width: 800px\) \{[\s\S]*?\.admin-expense-header \{[\s\S]*?grid-template-columns: 1fr;/);
});

test("official area codes stay hidden from user-facing UI and exports", async () => {
  const dashboard = await read("app/components/DashboardApp.tsx");
  const profileCard = await read("app/components/AccountProfileCard.tsx");
  const adminExpensePage = await read("app/components/AdminExpenseManagementPage.tsx");

  assert.doesNotMatch(dashboard, /অঞ্চল কোড|অফিসিয়াল area code|children: e\.areaCode|children: t\.code|children: e\.code|children: \[e\.name, ` \(`/);
  assert.doesNotMatch(profileCard, /display\.area_code \|\|/);
  assert.match(profileCard, /display\.area_code \? "নির্ধারিত অঞ্চল" : "উপজেলা পর্যায়ের পূর্ণ অনুমতি"/);
  assert.doesNotMatch(adminExpensePage, /<small>\{area\.code\}<\/small>/);
});

test("security cleanup keeps password hashing helpers in place", async () => {
  const passwordHelper = await read("app/lib/password.ts");
  const loginRoute = await read("app/api/auth/login/route.ts");
  const authHelper = await read("app/lib/auth.ts");
  const profileRoute = await read("app/api/profile/route.ts");
  const stockRoute = await read("app/api/stock/route.ts");
  const demandRoute = await read("app/api/schools/[emisCode]/demand/route.ts");
  const supplierRoute = await read("app/api/suppliers/[id]/ledger/route.ts");

  assert.match(passwordHelper, /PBKDF2_ITERATIONS = 210_000/);
  assert.match(passwordHelper, /pbkdf2-sha256:/);
  assert.match(loginRoute, /verifyPassword/);
  assert.match(loginRoute, /createSession\(user\.id\)/);
  assert.doesNotMatch(loginRoute, /WHERE username = \? AND password = \?/);
  assert.match(authHelper, /FROM sessions s/);
  assert.match(authHelper, /s\.expires_at > CURRENT_TIMESTAMP/);
  assert.doesNotMatch(authHelper, /JSON\.parse\(Buffer\.from/);
  assert.match(profileRoute, /\.bind\(authUser\.id\)/);
  assert.doesNotMatch(profileRoute, /data\.id/);
  assert.match(stockRoute, /requireSuperAdmin/);
  assert.match(demandRoute, /requireSuperAdmin/);
  assert.match(supplierRoute, /requireSuperAdmin/);
});

test("area manager account page and expense report API are wired", async () => {
  const page = await read("app/page.tsx");
  const accountPage = await read("app/components/AreaAccountPage.tsx");
  const accountStyles = await read("app/components/area-account-page.css");
  const expensesRoute = await read("app/api/expenses/route.ts");
  const accountRoute = await read("app/api/my-account/route.ts");
  const bootstrap = await read("db/bootstrap.ts");

  assert.match(page, /<AreaAccountPage/);
  assert.match(page, /userRole=\{user\.role \|\| ""\}/);
  assert.match(page, /button:nth-child\(5\)/);
  assert.match(page, /button:nth-child\(7\)/);
  const dashboard = await read("app/components/DashboardApp.tsx");
  assert.match(dashboard, /id: `account`, label: `হিসাব`/);
  assert.match(dashboard, /userRole: accountRole/);
  assert.match(dashboard, /accountRole === `area_manager`/);
  assert.match(dashboard, /CustomEvent\(`area-account-open`\)/);
  assert.match(accountPage, /title="হিসাব"/);
  assert.match(accountPage, /পেমেন্ট রিকোয়েস্ট পাঠান/);
  assert.match(accountPage, /\/api\/my-account/);
  assert.match(accountPage, /loadingRef/);
  assert.match(accountPage, /!open \|\| loaded/);
  assert.match(accountPage, /area-ledger-skeleton/);
  assert.match(accountPage, /closeWhenOtherNavOpens/);
  assert.match(accountPage, /button\.title === "হিসাব"/);
  assert.match(accountPage, /previousActiveNavRef/);
  assert.match(accountPage, /closingForNavigationRef/);
  assert.match(accountPage, /\.sidebar nav button\.nav-active:not\(\.area-account-nav\)/);
  assert.match(accountPage, /activeNav\?\.classList\.remove\("nav-active"\)/);
  assert.match(accountPage, /window\.addEventListener\("area-account-open", openAccountPage\)/);
  assert.match(accountPage, /accountNav\?\.classList\.add\("area-account-nav", "area-account-nav-active"\)/);
  assert.doesNotMatch(accountPage, /createPortal\(\s*<button[\s\S]*title="হিসাব"/);
  assert.match(accountPage, /setPageTarget\(main\)/);
  assert.match(accountPage, /area-account-open/);
  assert.match(accountPage, /pageTarget/);
  assert.match(accountStyles, /\.app-main\.area-account-open > :not\(\.topbar\):not\(\.notice\):not\(\.area-account-page\)/);
  assert.match(accountStyles, /\.area-account-page \{[\s\S]*?position: relative;/);
  assert.match(accountStyles, /\.area-account-nav \{[\s\S]*?order: 3;/);
  assert.match(accountStyles, /\.sidebar nav button:nth-child\(3\) \{[\s\S]*?order: 4;/);
  assert.doesNotMatch(accountStyles, /position: fixed;/);
  assert.match(accountRoute, /LIMIT 12/);
  assert.match(accountRoute, /SELECT\s+COALESCE/);
  assert.match(accountRoute, /Amount must be greater than zero/);
  assert.match(accountRoute, /Valid area and payment date are required/);
  assert.match(expensesRoute, /export async function GET/);
  assert.match(expensesRoute, /function expenseRange/);
  assert.match(expensesRoute, /period === "day"/);
  assert.match(expensesRoute, /period === "week"/);
  assert.match(expensesRoute, /area_expenses e/);
  assert.match(expensesRoute, /expenseDate/);
  assert.match(bootstrap, /expense_date TEXT NOT NULL/);
  assert.match(bootstrap, /ALTER TABLE area_expenses ADD COLUMN/);
});

test("desktop sidebar can collapse and expand without mobile injection", async () => {
  const dashboard = await read("app/components/DashboardApp.tsx");
  const sidebarStyles = await read("app/components/sidebar-collapse.css");

  assert.match(dashboard, /import "\.\/sidebar-collapse\.css"/);
  assert.match(dashboard, /sidebarCollapsed/);
  assert.match(dashboard, /setSidebarCollapsed/);
  assert.match(dashboard, /desktop-sidebar-toggle/);
  assert.match(dashboard, /সাইডবার ক্লোজ করুন/);
  assert.match(dashboard, /সাইডবার ওপেন করুন/);
  assert.match(sidebarStyles, /\.sidebar-collapsed \{/);
  assert.match(sidebarStyles, /\.sidebar-is-collapsed \.app-main \{[\s\S]*?margin-left: 84px;/);
  assert.match(sidebarStyles, /@media \(max-width: 800px\) \{[\s\S]*?\.desktop-sidebar-toggle \{[\s\S]*?display: none;/);
});

test("expense report supports day week and month filters", async () => {
  const dashboard = await read("app/components/DashboardApp.tsx");

  assert.match(dashboard, /expensePeriod/);
  assert.match(dashboard, /দিনভিত্তিক/);
  assert.match(dashboard, /সাপ্তাহিক/);
  assert.match(dashboard, /মাসিক/);
  assert.match(dashboard, /expenseRangeLabel/);
  assert.match(dashboard, /\/api\/expenses\?\$\{e\.toString\(\)\}/);
});

test("production manifests reference only emitted client chunks", async () => {
  const manifest = await read("dist/server/__vite_rsc_assets_manifest.js");
  const assets = [
    ...manifest.matchAll(/"\/assets\/([^"]+\.js)"/g),
  ].map((match) => match[1]);

  assert.ok(assets.length > 0);
  await Promise.all(
    assets.map((asset) =>
      access(new URL(`../dist/client/assets/${asset}`, import.meta.url)),
    ),
  );
});
