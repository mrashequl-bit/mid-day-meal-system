"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { createPortal } from "react-dom";
import { ArrowLeft, Banknote, CalendarDays, ReceiptText, Edit2, Trash2, Check, X } from "lucide-react";
import "./admin-expense-management-page.css";

type AreaSummary = {
  code: string;
  name: string;
  manager_name?: string | null;
  totalExpense?: number;
  totalPayment?: number;
  due?: number;
};

type ExpenseRow = {
  id: number;
  areaCode: string;
  areaName: string;
  expenseDate: string;
  vehicleType: string;
  amountPoisha: number;
  note?: string | null;
};

type LedgerRow = {
  id: number;
  date: string;
  type: string;
  amount: number;
  note?: string | null;
  category: "expense" | "payment";
};

type Props = {
  open: boolean;
  onClose?: () => void;
  standalone?: boolean;
};

const currency = new Intl.NumberFormat("bn-BD", { maximumFractionDigits: 0 });
const dateFormatter = new Intl.DateTimeFormat("bn-BD", {
  dateStyle: "medium",
});

function dateOnly(date: Date) {
  return date.toISOString().slice(0, 10);
}

function monthOnly(date: Date) {
  return dateOnly(date).slice(0, 7);
}

function taka(value = 0) {
  return `৳${currency.format(Math.round(value / 100))}`;
}

function periodLabel(period: string, month: string, date: string) {
  if (period === "month") {
    return `মাসিক রিপোর্ট: ${dateFormatter.format(new Date(`${month}-01T12:00:00`))}`;
  }
  const selected = new Date(`${date}T12:00:00`);
  if (period === "day") {
    return `দিনভিত্তিক রিপোর্ট: ${dateFormatter.format(selected)}`;
  }
  const start = new Date(selected);
  start.setDate(selected.getDate() - ((selected.getDay() + 6) % 7));
  const end = new Date(start);
  end.setDate(start.getDate() + 6);
  return `সাপ্তাহিক রিপোর্ট: ${dateFormatter.format(start)} - ${dateFormatter.format(end)}`;
}

export function AdminExpenseManagementPage({ open, onClose, standalone = false }: Props) {
  const [mounted, setMounted] = useState(false);
  const [summary, setSummary] = useState<AreaSummary[]>([]);
  const [expenses, setExpenses] = useState<ExpenseRow[]>([]);
  const [ledger, setLedger] = useState<LedgerRow[]>([]);
  const [selectedArea, setSelectedArea] = useState("all");
  const [period, setPeriod] = useState("month");
  const [month, setMonth] = useState(monthOnly(new Date()));
  const [date, setDate] = useState(dateOnly(new Date()));
  const [paymentDate, setPaymentDate] = useState(dateOnly(new Date()));
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [message, setMessage] = useState("");
  const [isPrintingLedger, setIsPrintingLedger] = useState(false);

  useEffect(() => {
    if (isPrintingLedger) {
      document.body.classList.add("printing-ledger-only");
      setTimeout(() => {
        window.print();
        document.body.classList.remove("printing-ledger-only");
        setIsPrintingLedger(false);
      }, 50);
    }
  }, [isPrintingLedger]);

  const [saving, setSaving] = useState(false);
  const [mutatingId, setMutatingId] = useState("");
  const [editingExpense, setEditingExpense] = useState<ExpenseRow | null>(null);
  const [expenseEditForm, setExpenseEditForm] = useState({
    expenseDate: "",
    vehicleType: "",
    amount: "",
    note: "",
  });
  const [editingPayment, setEditingPayment] = useState<LedgerRow | null>(null);
  const [paymentEditForm, setPaymentEditForm] = useState({
    date: "",
    amount: "",
    note: "",
  });

  useEffect(() => setMounted(true), []);

  useEffect(() => {
    if (!open || typeof window === "undefined") return;
    const targetArea = new URLSearchParams(window.location.search).get("area");
    if (!targetArea) return;
    setSelectedArea(targetArea);
    window.requestAnimationFrame(() => {
      document.getElementById("payment-manage")?.scrollIntoView({
        block: "start",
        behavior: "smooth",
      });
    });
  }, [open]);

  const loadSummary = useCallback(async () => {
    const response = await fetch("/api/my-account?summary=true", { cache: "no-store" });
    const data = (await response.json()) as { summary?: AreaSummary[]; error?: string };
    if (!response.ok) throw new Error(data.error || "অঞ্চল লোড করা যায়নি");
    const rows = data.summary || [];
    setSummary(rows);
    setSelectedArea((current) => current || "all");
  }, []);

  const loadExpenses = useCallback(async () => {
    const params = new URLSearchParams({ period });
    if (period === "month") params.set("month", month);
    else params.set("date", date);
    const response = await fetch(`/api/expenses?${params.toString()}`, { cache: "no-store" });
    const data = (await response.json()) as { expenses?: ExpenseRow[]; error?: string };
    if (!response.ok) throw new Error(data.error || "খরচের রিপোর্ট লোড করা যায়নি।");
    setExpenses(data.expenses || []);
  }, [date, month, period]);

  const loadLedger = useCallback(async () => {
    if (!selectedArea || selectedArea === "all") {
      setLedger([]);
      return;
    }
    const params = new URLSearchParams({ area_code: selectedArea });
    if (period === "month") params.set("month", month);
    const response = await fetch(`/api/my-account?${params.toString()}`, { cache: "no-store" });
    const data = (await response.json()) as { ledger?: LedgerRow[]; error?: string };
    if (!response.ok) throw new Error(data.error || "লেজার লোড করা যায়নি");
    setLedger(data.ledger || []);
  }, [selectedArea, period, month]);

  useEffect(() => {
    if (!open) return;
    loadSummary().catch((error) => setMessage(error instanceof Error ? error.message : "ডেটা লোড করা যায়নি।"));
  }, [loadSummary, open]);

  useEffect(() => {
    if (!open) return;
    loadExpenses().catch((error) => setMessage(error instanceof Error ? error.message : "রিপোর্ট লোড করা যায়নি।"));
  }, [loadExpenses, open]);

  useEffect(() => {
    if (!open) return;
    loadLedger().catch((error) => setMessage(error instanceof Error ? error.message : "লেজার লোড করা যায়নি।"));
  }, [loadLedger, open]);

  const expenseByArea = useMemo(() => {
    const totals = new Map<string, number>();
    expenses.forEach((expense) => {
      totals.set(expense.areaCode, (totals.get(expense.areaCode) || 0) + expense.amountPoisha);
    });
    return totals;
  }, [expenses]);

  const selectedSummary = selectedArea === "all" ? undefined : summary.find((area) => area.code === selectedArea);
  const selectedExpenseRows = selectedArea === "all" ? expenses : expenses.filter((expense) => expense.areaCode === selectedArea);
  const periodTotal = expenses.reduce((total, expense) => total + expense.amountPoisha, 0);
  const dueTotal = summary.reduce((total, area) => total + (area.due || 0), 0);
  const paymentTotal = summary.reduce((total, area) => total + (area.totalPayment || 0), 0);
  const rowsToRender = summary.filter((area) =>
    selectedArea === "all"
      ? expenseByArea.has(area.code) || (area.due || 0) > 0
      : area.code === selectedArea,
  );

  const ledgerTotalPayment = useMemo(() => {
    return ledger.filter(r => r.category === "payment").reduce((sum, r) => sum + r.amount, 0);
  }, [ledger]);

  const ledgerTotalExpense = useMemo(() => {
    return ledger.filter(r => r.category === "expense").reduce((sum, r) => sum + r.amount, 0);
  }, [ledger]);

  async function submitPayment(event: React.FormEvent<HTMLFormElement>) {
    event.preventDefault();
    if (!selectedArea || selectedArea === "all") {
      setMessage("পেমেন্ট দিতে নির্দিষ্ট একটি অঞ্চল নির্বাচন করুন।");
      return;
    }
    const dueTaka = Math.floor((selectedSummary?.due || 0) / 100);
    if (Number(amount) > dueTaka) {
      setMessage(`আপনি বকেয়া পরিমাণের (${currency.format(dueTaka)} টাকা) চেয়ে বেশি পেমেন্ট করতে পারবেন না।`);
      return;
    }
    setSaving(true);
    setMessage("");
    try {
      const response = await fetch("/api/my-account", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          area_code: selectedArea,
          payment_date: paymentDate,
          amount,
          note,
        }),
      });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(result.error || "পেমেন্ট সংরক্ষণ করা যায়নি।");
      setAmount("");
      setNote("");
      setMessage("পেমেন্ট সংরক্ষণ হয়েছে এবং Area Manager-এর হিসাবে যুক্ত হয়েছে।");
      await Promise.all([loadSummary(), loadLedger()]);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "পেমেন্ট সংরক্ষণ করা যায়নি।");
    } finally {
      setSaving(false);
    }
  }

  function startEditExpense(expense: ExpenseRow) {
    setEditingExpense(expense);
    setEditingPayment(null);
    setExpenseEditForm({
      expenseDate: expense.expenseDate,
      vehicleType: expense.vehicleType,
      amount: String(Math.round(expense.amountPoisha / 100)),
      note: expense.note || "",
    });
    setMessage("");
  }

  async function saveExpenseEdit(event?: React.FormEvent) {
    if (event) event.preventDefault();
    if (!editingExpense) return;
    const actionId = `expense-${editingExpense.id}`;
    setMutatingId(actionId);
    setMessage("");
    try {
      const response = await fetch("/api/expenses", {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          id: editingExpense.id,
          areaCode: editingExpense.areaCode,
          expenseDate: expenseEditForm.expenseDate,
          vehicleType: expenseEditForm.vehicleType,
          amount: expenseEditForm.amount,
          note: expenseEditForm.note,
        }),
      });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(result.error || "পেমেন্ট রিকোয়েস্ট আপডেট করা যায়নি।");
      setEditingExpense(null);
      setMessage("পেমেন্ট রিকোয়েস্ট আপডেট হয়েছে।");
      await Promise.all([loadSummary(), loadExpenses(), loadLedger()]);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "পেমেন্ট রিকোয়েস্ট আপডেট করা যায়নি।");
    } finally {
      setMutatingId("");
    }
  }

  async function deleteExpense(id: number) {
    if (!window.confirm("এই পেমেন্ট রিকোয়েস্টটি ডিলিট করতে চান?")) return;
    const actionId = `expense-${id}`;
    setMutatingId(actionId);
    setMessage("");
    try {
      const response = await fetch(`/api/expenses?id=${id}`, { method: "DELETE" });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(result.error || "পেমেন্ট রিকোয়েস্ট ডিলিট করা যায়নি।");
      if (editingExpense?.id === id) setEditingExpense(null);
      setMessage("পেমেন্ট রিকোয়েস্ট ডিলিট হয়েছে।");
      await Promise.all([loadSummary(), loadExpenses(), loadLedger()]);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "পেমেন্ট রিকোয়েস্ট ডিলিট করা যায়নি।");
    } finally {
      setMutatingId("");
    }
  }

  function startEditPayment(row: LedgerRow) {
    setEditingPayment(row);
    setEditingExpense(null);
    setPaymentEditForm({
      date: row.date,
      amount: String(Math.round(row.amount / 100)),
      note: row.note || "",
    });
    setMessage("");
  }

  function startEditLedgerExpense(row: LedgerRow) {
    const expense = expenses.find((item) => item.id === row.id) || {
      id: row.id,
      areaCode: selectedArea,
      areaName: selectedSummary?.name || "",
      expenseDate: row.date,
      vehicleType: row.type,
      amountPoisha: row.amount,
      note: row.note,
    };
    startEditExpense(expense);
  }

  async function savePaymentEdit(event?: React.FormEvent) {
    if (event) event.preventDefault();
    if (!editingPayment) return;
    const actionId = `payment-${editingPayment.id}`;
    setMutatingId(actionId);
    setMessage("");
    try {
      const response = await fetch("/api/my-account", {
        method: "PUT",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          id: editingPayment.id,
          payment_date: paymentEditForm.date,
          amount: paymentEditForm.amount,
          note: paymentEditForm.note,
        }),
      });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(result.error || "পেমেন্ট আপডেট করা যায়নি।");
      setEditingPayment(null);
      setMessage("পেমেন্ট আপডেট হয়েছে।");
      await Promise.all([loadSummary(), loadLedger()]);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "পেমেন্ট আপডেট করা যায়নি।");
    } finally {
      setMutatingId("");
    }
  }

  async function deletePayment(id: number) {
    if (!window.confirm("এই পেমেন্ট রেকর্ডটি ডিলিট করতে চান?")) return;
    const actionId = `payment-${id}`;
    setMutatingId(actionId);
    setMessage("");
    try {
      const response = await fetch(`/api/my-account?id=${id}`, { method: "DELETE" });
      const result = (await response.json()) as { error?: string };
      if (!response.ok) throw new Error(result.error || "পেমেন্ট ডিলিট করা যায়নি।");
      if (editingPayment?.id === id) setEditingPayment(null);
      setMessage("পেমেন্ট ডিলিট হয়েছে।");
      await Promise.all([loadSummary(), loadLedger()]);
    } catch (error) {
      setMessage(error instanceof Error ? error.message : "পেমেন্ট ডিলিট করা যায়নি।");
    } finally {
      setMutatingId("");
    }
  }

  const closePage = onClose ?? (() => {
    window.location.href = "/";
  });

  if (!open) return null;

  const pageContent = (
    <main className={standalone ? "admin-expense-page admin-expense-standalone" : "admin-expense-page"} aria-label="অঞ্চলভিত্তিক খরচ ও পেমেন্ট ম্যানেজমেন্ট">
      <header className="admin-expense-header">
        <button type="button" className="admin-expense-back" onClick={closePage}>
          <ArrowLeft aria-hidden="true" /> ড্যাশবোর্ডে ফিরুন
        </button>
        <div>
          <p className="eyebrow">Expense Payment Management</p>
          <h1>অঞ্চলভিত্তিক খরচ</h1>
          <span>যানবাহন ও অন্যান্য দৈনিক ব্যয়ের রিপোর্ট, পেমেন্ট রিকোয়েস্ট ও পরিশোধ ব্যবস্থাপনা</span>
        </div>
      </header>

      <section className="admin-expense-filters panel no-print">
        <label>
          রিপোর্ট ধরন
          <select value={period} onChange={(event) => setPeriod(event.target.value)}>
            <option value="day">দিনভিত্তিক</option>
            <option value="week">সাপ্তাহিক</option>
            <option value="month">মাসিক</option>
          </select>
        </label>
        {period === "month" ? (
          <label>
            মাস
            <input type="month" value={month} onChange={(event) => setMonth(event.target.value)} />
          </label>
        ) : (
          <label>
            তারিখ
            <input type="date" value={date} onChange={(event) => setDate(event.target.value)} />
          </label>
        )}
        <label>
          অঞ্চল
          <select value={selectedArea} onChange={(event) => setSelectedArea(event.target.value)}>
            <option value="all">সকল অঞ্চল</option>
            {summary.map((area) => (
              <option value={area.code} key={area.code}>{area.name}</option>
            ))}
          </select>
        </label>
        <strong>{periodLabel(period, month, date)}</strong>
      </section>

      {message && <p className="admin-expense-message" role="status">{message}</p>}

      <section className="admin-expense-metrics">
        <article><CalendarDays aria-hidden="true" /><small>নির্বাচিত সময়ের খরচ</small><strong>{taka(periodTotal)}</strong></article>
        <article><Banknote aria-hidden="true" /><small>মোট পরিশোধ</small><strong>{taka(paymentTotal)}</strong></article>
        <article><ReceiptText aria-hidden="true" /><small>বর্তমান বকেয়া</small><strong>{taka(dueTotal)}</strong></article>
      </section>

      <section className="admin-expense-grid">
        <section className="panel admin-expense-report">
          <div className="panel-head">
            <div>
              <p className="eyebrow">Area Report</p>
              <h2>অঞ্চলভিত্তিক খরচের তালিকা</h2>
            </div>
          </div>
          <div className="table-scroll">
            <table>
              <thead>
                <tr>
                  <th>অঞ্চল</th>
                  <th>Area Manager</th>
                  <th>নির্বাচিত সময়ের খরচ</th>
                  <th>মোট পরিশোধ</th>
                  <th>বর্তমান বকেয়া</th>
                  <th className="no-print">অ্যাকশন</th>
                </tr>
              </thead>
              <tbody>
                {rowsToRender.length ? rowsToRender.map((area) => (
                  <tr key={area.code} className={area.code === selectedArea ? "admin-expense-selected-row" : ""}>
                    <td><strong>{area.name}</strong></td>
                    <td>{area.manager_name || "পদ খালি"}</td>
                    <td>{taka(expenseByArea.get(area.code) || 0)}</td>
                    <td>{taka(area.totalPayment || 0)}</td>
                    <td><strong>{taka(area.due || 0)}</strong></td>
                    <td className="no-print">
                      <button type="button" className="table-action" onClick={() => setSelectedArea(area.code)}>
                        পেমেন্ট ম্যানেজ
                      </button>
                    </td>
                  </tr>
                )) : (
                  <tr>
                    <td colSpan={6} className="admin-expense-empty">এই সময়ের জন্য কোনো খরচ বা বকেয়া পাওয়া যায়নি।</td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </section>

        <aside className="panel admin-payment-panel" id="payment-manage">
          <div className="print-only-header" style={{ display: "none", textAlign: "center", marginBottom: "20px" }}>
            <h1 style={{ fontSize: "24px", margin: "0", color: "#111827" }}>পরিবহণ এবং অন্যান্য খরচের হিসাব</h1>
            <p style={{ fontSize: "14px", margin: "4px 0 0", color: "#4b5563" }}>{periodLabel(period, month, date)}</p>
            <p style={{ fontSize: "16px", fontWeight: "bold", margin: "4px 0 0", color: "#111827" }}>{selectedSummary?.name}</p>
          </div>
          <div className="panel-head">
            <div>
              <p className="eyebrow">Payment</p>
              <h2>পেমেন্ট ম্যানেজ</h2>
              <span>{selectedSummary?.name || "পেমেন্টের জন্য নির্দিষ্ট অঞ্চল নির্বাচন করুন"}</span>
            </div>
          </div>
          <div className="admin-payment-due">
            <small>বর্তমান বকেয়া</small>
            <strong>{taka(selectedSummary?.due || 0)}</strong>
          </div>
          <form className="admin-payment-form" onSubmit={submitPayment}>
            <label>
              পেমেন্ট তারিখ
              <input type="date" required value={paymentDate} onChange={(event) => setPaymentDate(event.target.value)} />
            </label>
            <label>
              পরিশোধের পরিমাণ
              <input required min="1" max={Math.floor((selectedSummary?.due || 0) / 100)} inputMode="decimal" type="number" value={amount} onChange={(event) => setAmount(event.target.value)} placeholder="টাকায় লিখুন" />
            </label>
            <label>
              নোট
              <textarea rows={3} value={note} onChange={(event) => setNote(event.target.value)} placeholder="যেমন: নগদ প্রদান / ব্যাংক ট্রান্সফার" />
            </label>
            <button type="submit" className="button-primary" disabled={saving || !selectedArea || selectedArea === "all" || (selectedSummary?.due || 0) <= 0}>
              {saving ? "সংরক্ষণ হচ্ছে..." : "পেমেন্ট সংরক্ষণ করুন"}
            </button>
          </form>

          <div className="admin-ledger-list">
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <h3>লেজার {period === "month" && ledger.length > 0 ? `(${month})` : ""}</h3>
              {ledger.length > 0 && (
                <button
                  type="button"
                  className="button-secondary no-print"
                  style={{ padding: "4px 8px", fontSize: "12px", display: "flex", alignItems: "center", gap: "4px" }}
                  onClick={() => setIsPrintingLedger(true)}
                >
                  প্রিন্ট করুন
                </button>
              )}
            </div>
            {ledger.length ? (
              <table className="ledger-book-table" style={{ marginTop: "12px" }}>
                <thead>
                  <tr>
                    <th>তারিখ</th>
                    <th>বিবরণ</th>
                    <th>প্রদান</th>
                    <th>খরচ</th>
                    <th style={{ width: "60px", textAlign: "center" }}>অ্যাকশন</th>
                  </tr>
                </thead>
                <tbody>
                  {ledger.slice().reverse().map((row) => {
                    const isEditing = editingPayment?.id === row.id && row.category === "payment";
                    const isMutating = mutatingId === `${row.category}-${row.id}`;

                    if (isEditing) {
                      return (
                        <tr key={`${row.category}-${row.id}`}>
                          <td style={{ padding: "4px" }}>
                            <input
                              type="date"
                              value={paymentEditForm.date}
                              onChange={(e) => setPaymentEditForm((f) => ({ ...f, date: e.target.value }))}
                              required
                              disabled={isMutating}
                              style={{ width: "100%", padding: "4px", fontSize: "12px" }}
                            />
                          </td>
                          <td colSpan={2} style={{ padding: "4px" }}>
                            <input
                              type="text"
                              value={paymentEditForm.note}
                              onChange={(e) => setPaymentEditForm((f) => ({ ...f, note: e.target.value }))}
                              placeholder="মন্তব্য (ঐচ্ছিক)"
                              disabled={isMutating}
                              style={{ width: "100%", padding: "4px", fontSize: "12px" }}
                            />
                          </td>
                          <td style={{ padding: "4px" }}>
                            <input
                              type="number"
                              value={paymentEditForm.amount}
                              onChange={(e) => setPaymentEditForm((f) => ({ ...f, amount: e.target.value }))}
                              placeholder="টাকা"
                              min="1"
                              required
                              disabled={isMutating}
                              style={{ width: "100%", padding: "4px", fontSize: "12px" }}
                            />
                          </td>
                          <td style={{ padding: "4px", textAlign: "center", whiteSpace: "nowrap" }}>
                            <button
                              type="button"
                              className="ledger-action-btn"
                              onClick={() => savePaymentEdit()}
                              disabled={isMutating || !paymentEditForm.date || !paymentEditForm.amount}
                              title="সেভ করুন"
                            >
                              <Check size={16} />
                            </button>
                            <button
                              type="button"
                              className="ledger-action-btn danger"
                              onClick={() => setEditingPayment(null)}
                              disabled={isMutating}
                              title="বাতিল করুন"
                            >
                              <X size={16} />
                            </button>
                          </td>
                        </tr>
                      );
                    }

                    return (
                      <tr key={`${row.category}-${row.id}`}>
                        <td style={{ whiteSpace: "nowrap" }}>{dateFormatter.format(new Date(`${row.date}T12:00:00`))}</td>
                        <td style={{ whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis", maxWidth: "120px" }}>
                          <strong>{row.type === "payment" ? "পরিশোধ করা হয়েছে" : row.type}</strong>
                          {row.note && <span style={{ color: "var(--muted)", marginLeft: "4px", fontWeight: "normal" }}>({row.note})</span>}
                        </td>
                        <td style={{ color: "var(--green)", fontWeight: 600, whiteSpace: "nowrap" }}>
                          {row.category === "payment" ? taka(row.amount) : "-"}
                        </td>
                        <td style={{ color: "#805200", fontWeight: 600, whiteSpace: "nowrap" }}>
                          {row.category === "expense" ? taka(row.amount) : "-"}
                        </td>
                        <td style={{ textAlign: "center", whiteSpace: "nowrap" }}>
                          <button
                            type="button"
                            className="ledger-action-btn"
                            onClick={() => row.category === "payment" ? startEditPayment(row) : startEditLedgerExpense(row)}
                            disabled={!!mutatingId}
                            title="এডিট করুন"
                          >
                            <Edit2 size={16} />
                          </button>
                          <button
                            type="button"
                            className="ledger-action-btn danger"
                            onClick={() => row.category === "payment" ? deletePayment(row.id) : deleteExpense(row.id)}
                            disabled={!!mutatingId}
                            title="ডিলিট করুন"
                          >
                            <Trash2 size={16} />
                          </button>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
                <tfoot>
                  <tr className="print-only-footer">
                    <td colSpan={2} style={{ textAlign: "right", fontWeight: "bold" }}>সর্বমোট:</td>
                    <td style={{ fontWeight: "bold", color: "var(--green)" }}>{taka(ledgerTotalPayment)}</td>
                    <td style={{ fontWeight: "bold", color: "var(--danger)" }}>{taka(ledgerTotalExpense)}</td>
                    <td className="no-print"></td>
                  </tr>
                </tfoot>
              </table>
            ) : (
              <p className="admin-expense-empty">এই অঞ্চলের কোনো লেজার নেই।</p>
            )}
          </div>
        </aside>
      </section>

      <section className="panel admin-expense-details">
        <div className="panel-head">
          <div>
            <p className="eyebrow">Daily Request</p>
            <h2>নির্বাচিত অঞ্চলের পেমেন্ট রিকোয়েস্ট</h2>
          </div>
        </div>
        <div className="table-scroll">
          <table>
            <thead>
              <tr>
                <th>তারিখ</th>
                <th>কিসের খরচ?</th>
                <th>পরিমাণ</th>
                <th>মন্তব্য</th>
                <th className="no-print">অ্যাকশন</th>
              </tr>
            </thead>
            <tbody>
              {selectedExpenseRows.length ? selectedExpenseRows.map((expense) => {
                const isEditing = editingExpense?.id === expense.id;
                const isMutating = mutatingId === `expense-${expense.id}`;

                if (isEditing) {
                  return (
                    <tr key={expense.id} className="admin-expense-edit-row">
                      <td>
                        <input
                          type="date"
                          value={expenseEditForm.expenseDate}
                          onChange={(e) => setExpenseEditForm((f) => ({ ...f, expenseDate: e.target.value }))}
                          required
                          disabled={isMutating}
                        />
                      </td>
                      <td>
                        <input
                          type="text"
                          value={expenseEditForm.vehicleType}
                          onChange={(e) => setExpenseEditForm((f) => ({ ...f, vehicleType: e.target.value }))}
                          placeholder="যানবাহন/খরচ"
                          required
                          disabled={isMutating}
                        />
                      </td>
                      <td>
                        <input
                          type="number"
                          value={expenseEditForm.amount}
                          onChange={(e) => setExpenseEditForm((f) => ({ ...f, amount: e.target.value }))}
                          placeholder="টাকা"
                          min="1"
                          required
                          disabled={isMutating}
                          style={{ width: "80px" }}
                        />
                      </td>
                      <td>
                        <input
                          type="text"
                          value={expenseEditForm.note}
                          onChange={(e) => setExpenseEditForm((f) => ({ ...f, note: e.target.value }))}
                          placeholder="মন্তব্য (ঐচ্ছিক)"
                          disabled={isMutating}
                        />
                      </td>
                      <td className="no-print" style={{ display: "flex", gap: "8px" }}>
                        <button
                          type="button"
                          className="button-primary"
                          onClick={() => saveExpenseEdit()}
                          disabled={isMutating || !expenseEditForm.expenseDate || !expenseEditForm.vehicleType || !expenseEditForm.amount}
                        >
                          {isMutating ? "সেভ হচ্ছে..." : "সেভ"}
                        </button>
                        <button
                          type="button"
                          className="button-secondary"
                          onClick={() => setEditingExpense(null)}
                          disabled={isMutating}
                        >
                          ক্যান্সেল
                        </button>
                      </td>
                    </tr>
                  );
                }

                return (
                  <tr key={expense.id}>
                    <td>{dateFormatter.format(new Date(`${expense.expenseDate}T12:00:00`))}</td>
                    <td>{expense.vehicleType}</td>
                    <td>{taka(expense.amountPoisha)}</td>
                    <td>{expense.note || "-"}</td>
                    <td className="no-print" style={{ display: "flex", gap: "8px" }}>
                      <button
                        type="button"
                        className="table-action"
                        onClick={() => startEditExpense(expense)}
                        disabled={!!mutatingId}
                      >
                        এডিট
                      </button>
                      <button
                        type="button"
                        className="table-action"
                        style={{ color: "var(--danger)" }}
                        onClick={() => deleteExpense(expense.id)}
                        disabled={!!mutatingId}
                      >
                        ডিলিট
                      </button>
                    </td>
                  </tr>
                );
              }) : (
                <tr>
                  <td colSpan={5} className="admin-expense-empty">নির্বাচিত সময়ের জন্য এই অঞ্চলে কোনো পেমেন্ট রিকোয়েস্ট নেই।</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </section>
    </main>
  );

  if (standalone) return pageContent;
  if (!mounted) return null;

  return createPortal(
    pageContent,
    document.body,
  );
}
