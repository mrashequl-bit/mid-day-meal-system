import { redirect } from "next/navigation";
import { AccountProfileCard } from "../components/AccountProfileCard";
import { AppChrome } from "../components/AppChrome";
import { AdminExpenseManagementPage } from "../components/AdminExpenseManagementPage";
import { NotificationCenter } from "../components/NotificationCenter";
import { getAuthUser } from "../lib/auth";

export const dynamic = "force-dynamic";

export const metadata = {
  title: "অঞ্চলভিত্তিক খরচ | মিড-ডে মিল",
  description: "অঞ্চলভিত্তিক যানবাহন ও অন্যান্য খরচের dedicated রিপোর্ট পেইজ",
};

export default async function AreaExpensesPage() {
  const user = await getAuthUser();
  if (!user || user.role !== "super_admin") {
    redirect("/");
  }

  return (
    <>
      <AccountProfileCard
        fallbackName={user.name || "Super Admin"}
        fallbackEmail={user.mobile || ""}
      />
      <AppChrome>
        <AdminExpenseManagementPage open standalone />
      </AppChrome>
      <NotificationCenter />
    </>
  );
}
