import { NextResponse } from "next/server";
import { ensureDatabase } from "../../../../db/bootstrap";
import { requireSuperAdmin } from "../../../lib/auth";
import { hashPassword } from "../../../lib/password";

export async function PUT(
  request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await requireSuperAdmin())) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  try {
    const { id } = await params;
    const data = await request.json() as Record<string, unknown>;
    const nextPassword = String(data.password ?? "");
    const db = await ensureDatabase();
    await db.prepare(
      `UPDATE users SET username = ?,
       password = COALESCE(NULLIF(?, ''), password), name = ?, role = ?,
       area_code = ?, is_active = ?, email = ?, phone = ?, bio = ?,
       address = ?, designation = ?, updated_at = CURRENT_TIMESTAMP
       WHERE id = ?`
    ).bind(
      String(data.username ?? "").trim(),
      nextPassword ? await hashPassword(nextPassword) : "",
      String(data.name ?? "").trim(),
      String(data.role ?? "viewer"),
      data.role === "area_manager" ? String(data.area_code ?? "") : null,
      data.is_active === 0 ? 0 : 1,
      String(data.email ?? "").trim(),
      String(data.phone ?? "").trim(),
      String(data.bio ?? "").trim(),
      String(data.address ?? "").trim(),
      String(data.designation ?? "").trim(),
      id,
    ).run();
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "User update failed" },
      { status: 500 },
    );
  }
}

export async function DELETE(
  _request: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  if (!(await requireSuperAdmin())) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  try {
    const { id } = await params;
    const db = await ensureDatabase();
    await db.prepare("DELETE FROM users WHERE id = ? AND role != 'super_admin'").bind(id).run();
    return NextResponse.json({ success: true });
  } catch (error) {
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "User delete failed" },
      { status: 500 },
    );
  }
}
