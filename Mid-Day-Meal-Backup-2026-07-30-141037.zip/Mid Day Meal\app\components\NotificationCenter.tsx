"use client";

import { useCallback, useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { Bell } from "lucide-react";
import "./notification-center.css";

type Notification = {
  id: number;
  type: string;
  area_code?: string | null;
  title: string;
  message: string;
  time?: string | null;
};

const bengaliNumber = new Intl.NumberFormat("bn-BD", {
  useGrouping: false,
});

export function NotificationCenter() {
  const [target, setTarget] = useState<HTMLButtonElement | null>(null);
  const [mobileTarget, setMobileTarget] = useState<Element | null>(null);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [open, setOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  const loadNotifications = useCallback(async () => {
    try {
      const response = await fetch("/api/notifications", { cache: "no-store" });
      if (!response.ok) throw new Error("notifications unavailable");
      const data = (await response.json()) as {
        notifications?: Notification[];
      };
      setNotifications(data.notifications || []);
    } catch {
      setNotifications([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const locate = () => {
      setTarget(document.querySelector<HTMLButtonElement>(".alert-button"));
      setMobileTarget(document.querySelector(".sidebar"));
    };
    locate();
    const observer = new MutationObserver(locate);
    observer.observe(document.body, { childList: true, subtree: true });
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    loadNotifications();
    const timer = window.setInterval(loadNotifications, 30_000);
    return () => window.clearInterval(timer);
  }, [loadNotifications]);

  useEffect(() => {
    if (!target) return;
    const count = bengaliNumber.format(notifications.length);
    target.dataset.count = count;
    target.textContent = count;
    target.setAttribute(
      "aria-label",
      notifications.length
        ? `${count}টি নতুন নোটিফিকেশন`
        : "নতুন নোটিফিকেশন নেই",
    );
    target.setAttribute("aria-expanded", String(open));
    target.setAttribute("aria-haspopup", "dialog");
    const toggle = () => setOpen((current) => !current);
    target.addEventListener("click", toggle);
    return () => target.removeEventListener("click", toggle);
  }, [notifications.length, open, target]);

  function notificationTargetUrl(notification: Notification) {
    if (notification.type === "expense" && notification.area_code) {
      return `/area-expenses?area=${encodeURIComponent(notification.area_code)}#payment-manage`;
    }
    return (notification as any).link || "";
  }

  async function markRead(notification: Notification) {
    const response = await fetch("/api/notifications", {
      method: "POST",
      headers: { "content-type": "application/json" },
      body: JSON.stringify({ id: notification.id, type: notification.type }),
    });
    if (response.ok) {
      setNotifications((current) =>
        current.filter((item) => item.id !== notification.id),
      );
    }
    return response.ok;
  }

  async function openNotification(notification: Notification) {
    const targetUrl = notificationTargetUrl(notification);
    const wasMarkedRead = await markRead(notification);
    if (targetUrl && wasMarkedRead) {
      window.location.href = targetUrl;
    }
  }

  const count = bengaliNumber.format(notifications.length);
  const notificationLabel = notifications.length
    ? `${count}টি নতুন নোটিফিকেশন`
    : "নতুন নোটিফিকেশন নেই";

  return (
    <>
      {mobileTarget &&
        createPortal(
          <button
            className="mobile-notification-launcher"
            type="button"
            aria-label={notificationLabel}
            aria-expanded={open}
            aria-haspopup="dialog"
            onClick={() => setOpen((current) => !current)}
          >
            <span aria-hidden="true"><Bell /></span>
            {notifications.length > 0 && <b>{count}</b>}
          </button>,
          mobileTarget,
        )}
      {target &&
        open &&
        createPortal(
          <div
            className="notification-layer"
            role="presentation"
            onClick={() => setOpen(false)}
          >
            <section
              className="notification-panel"
              role="dialog"
              aria-modal="true"
              aria-label="নোটিফিকেশন"
              onClick={(event) => event.stopPropagation()}
            >
              <header>
                <div>
                  <small>Live Updates</small>
                  <h2>নোটিফিকেশন</h2>
                </div>
                <button
                  type="button"
                  aria-label="নোটিফিকেশন বন্ধ করুন"
                  onClick={() => setOpen(false)}
                >
                  ×
                </button>
              </header>
              <div className="notification-list">
                {loading ? (
                  <p className="notification-empty">লোড হচ্ছে…</p>
                ) : notifications.length ? (
                  notifications.map((notification) => (
                    <article
                      key={`${notification.type}-${notification.id}`}
                      role={notificationTargetUrl(notification) ? "button" : undefined}
                      tabIndex={notificationTargetUrl(notification) ? 0 : undefined}
                      onClick={() => openNotification(notification)}
                      onKeyDown={(event) => {
                        if (event.key === "Enter" || event.key === " ") {
                          event.preventDefault();
                          openNotification(notification);
                        }
                      }}
                    >
                      <span aria-hidden="true">!</span>
                      <div>
                        <strong>{notification.title}</strong>
                        <p>{notification.message}</p>
                        {notification.time && <small>{notification.time}</small>}
                      </div>
                      <button
                        type="button"
                        onClick={(event) => {
                          event.stopPropagation();
                          openNotification(notification);
                        }}
                      >
                        {notificationTargetUrl(notification) 
                          ? (notification.type === 'distribution_issue' ? "বিতরণ সমস্যা" : "পেমেন্ট ম্যানেজ") 
                          : "পড়া হয়েছে"}
                      </button>
                    </article>
                  ))
                ) : (
                  <p className="notification-empty">নতুন কোনো নোটিফিকেশন নেই।</p>
                )}
              </div>
            </section>
          </div>,
          document.body,
        )}
    </>
  );
}
