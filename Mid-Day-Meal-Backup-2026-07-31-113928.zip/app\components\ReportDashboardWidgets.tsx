"use client";

import { useEffect, useState } from "react";
import { createPortal } from "react-dom";
import { Download, TrendingDown, Truck } from "lucide-react";
import "./report-dashboard-widgets.css";

const reportWidgets = [
  {
    key: "shortage",
    title: "শর্টেজ ও ক্ষতিপূরণ",
    description: "কম সরবরাহ এবং নগদ ক্ষতিপূরণের হিসাব",
    icon: TrendingDown,
  },
  {
    key: "expense",
    title: "অঞ্চলভিত্তিক খরচ",
    description: "যানবাহন ও অন্যান্য দৈনিক ব্যয়ের রিপোর্ট",
    icon: Truck,
  },
  {
    key: "export",
    title: "PDF ও Excel রিপোর্ট",
    description: "রিপোর্ট প্রিন্ট অথবা Excel/CSV-তে ডাউনলোড",
    icon: Download,
  },
];

export function ReportDashboardWidgets() {
  const [target, setTarget] = useState<Element | null>(null);

  useEffect(() => {
    const locate = () =>
      setTarget(document.querySelector(".action-panel .action-list"));
    locate();
    const observer = new MutationObserver(locate);
    observer.observe(document.body, { childList: true, subtree: true });
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!target) return;
    const panel = target.closest(".action-panel");
    const eyebrow = panel?.querySelector<HTMLElement>(".eyebrow");
    const heading = panel?.querySelector<HTMLElement>("h2");
    const previousEyebrow = eyebrow?.textContent || "";
    const previousHeading = heading?.textContent || "";
    target.classList.add("report-widget-host");
    panel?.classList.add("report-dashboard-panel");
    if (heading) heading.textContent = "রিপোর্ট";
    return () => {
      target.classList.remove("report-widget-host");
      panel?.classList.remove("report-dashboard-panel");
      if (eyebrow) eyebrow.textContent = previousEyebrow;
      if (heading) heading.textContent = previousHeading;
    };
  }, [target]);

  function openReports() {
    const reportButton = Array.from(
      document.querySelectorAll<HTMLButtonElement>(".sidebar nav button"),
    ).find(
      (button) =>
        button.getAttribute("title") === "রিপোর্ট" ||
        button.textContent?.includes("রিপোর্ট"),
    );
    reportButton?.click();
    window.setTimeout(() => {
      document
        .querySelector(".report-preview")
        ?.scrollIntoView({ behavior: "smooth", block: "start" });
    }, 100);
  }

  function openExpenseWorkspace() {
    window.dispatchEvent(new CustomEvent("open-area-expense-workspace"));
  }

  if (!target) return null;

  return createPortal(
    <div className="report-widget-grid" aria-label="রিপোর্ট শর্টকাট">
      {reportWidgets.map(({ key, title, description, icon: Icon }) => (
        <button
          type="button"
          key={title}
          onClick={key === "expense" ? openExpenseWorkspace : openReports}
        >
          <span aria-hidden="true">
            <Icon />
          </span>
          <span>
            <strong>{title}</strong>
            <small>{description}</small>
          </span>
          <b aria-hidden="true">›</b>
        </button>
      ))}
    </div>,
    target,
  );
}
